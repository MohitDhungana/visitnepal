<?php 
   session_start();
     if (!isset($_SESSION['admin-login'])){
      // header(string:"Location:login.php");
      header("location:login.php");
      exit();
     }else{
      $id= $_SESSION['admin-login'];
     } 
     ?>

<?php

       include '../partials/header.php' ?>
 
<body>
   <?php include '../partials/college-nav.php' ?>

   <?php 
       $sql = "SELECT * FROM college where user_id=".$id;
      $result= mysqli_query($conn,$sql);
                $res_fetch = mysqli_fetch_assoc($result);
                $college_id=$res_fetch['id'];
  
    $result1= mysqli_query($conn, "SELECT * FROM review where college_id=$college_id");
  
    
  
   $info_user=mysqli_query($conn,"SELECT * FROM user WHERE college_id = $college_id");
    $program_result=mysqli_query($conn,"SELECT * FROM programs WHERE college_id = $college_id");
  

  ?>


  


<div class="container-fluid">
    <div class="row">
        <div class="col-md-4">
            <?php include '../partials/side-menu.php' ?>
        </div>
        <div class="col-md-8">
            <div class="well">
            <h2>view Reviews </h2>
             

             <div class="form-group">
            <label for="comment"><?= $res_fetch['name']?></label>
             <form> 

               <?php 
              while ($res = mysqli_fetch_assoc($result1)) {?>

               <?php 
                // $info_user=mysqli_query($conn,"SELECT * FROM user WHERE id=$res['user_id']");
                // $resu = mysqli_fetch_assoc($info_user);

                ?>
         <!--  <div class="form-group">
            <label for="comment"><? //echo $resu['name'];?></label> -->
            
            <input type="text" class="form-control" rows="7" id="review" value="<?= $res['review']?>" name="review">
            <br>   
             <?php 
         } ?>

          </form>
            </div>
        </div>
    </div>
</div>
<div class="panel-footer" style="text-align: center;">© Kathford International</div>
</body>

</html> 