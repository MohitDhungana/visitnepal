<?php 
   session_start();
     if (!isset($_SESSION['admin-login'])){
      // header(string:"Location:login.php");
      header("location:login.php");
      exit();
     }else{
      $id= $_SESSION['admin-login'];
     } 
     ?>

<?php

       include '../partials/header.php' ?>
  <?php
         $sql = "SELECT * FROM college where user_id=".$id;
      $result= mysqli_query($conn,$sql);
                $res_fetch = mysqli_fetch_assoc($result);
                $college_id=$res_fetch['id'];
    ?>

<?php
  if (isset($_POST['submit'])) {
       $tel_no = $_POST['tel_no'];
       $postal_add = $_POST['postal_add'];
           $email = $_POST['email'];
       $sql_check_information="SELECT * FROM `contact` WHERE college_id='$college_id' ";
       $result_check=mysqli_query($conn,$sql_check_information); //run the query $sql
       
    if(mysqli_num_rows($result_check)){
            $error = 'contact already exists';
          }
    else{   
        
            
            $que = "INSERT INTO `contact`(college_id,tel_no, postal_add,email,fax_no) VALUES ('$college_id','$tel_no','$postal_add','$email','$fax_no') ";
           
           }
           if(mysqli_query($conn,$que)){
               $success = 'true';
               echo "sucess";
          }else{
            $error = 'true';
      }
    
    }
  // else{
  //   //header("location:collegedashboard.php");
  //   echo 'error';
  // }
?>

   <body>
   <?php include '../partials/college-nav.php' ?>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-4">
            <?php include '../partials/side-menu.php' ?>
        </div>
        <div class="col-md-8">
            <div class="well">
            <h2>Add Contact</h2>
              <form method="POST" name="myForm"  onsubmit="return validate();" action="add-contact.php?id=<?=$college_id?>" enctype="multipart/form-data">
              <div class="form-group">
            <label for="comment">telephone no</label>
            <textarea class="form-control" rows="1" id="tel_no" name="tel_no"></textarea>
          </div>
             <div class="form-group">
            <label for="comment">postal address</label>
            <textarea class="form-control" rows="3" id="postal_add" name="postal_add"></textarea>
          </div>
           <div class="form-group">
            <label for="comment">email</label>
            <textarea class="form-control" rows="1" id="email" name="email"></textarea>
          </div>
           <div class="form-group">
            <label for="comment">fax number</label>
            <textarea class="form-control" rows="3" id="fax_no" name="fax_no"></textarea>
          </div>
         
            <div class="alert alert-danger" id="error-div" style="display: none;">
              <span class="glyphicon glyphicon-exclamation-sign" id="error" aria-hidden= 'true' >your account is not register</span>
            </div>
            <div class="form-group">
              <button class="btn btn-sucess pull-right" style="margin-right: 10px" type="submit" name="submit">save</button>
            <br></div>
            <?php 
              if (isset($success)) {
                echo "<div class='alert alert-success' id='success-div'>
                    <span class='glyphicon glyphicon-exclamation-sign' aria-hidden= 'true' > Added Successfully </span>
                    </div>";
              }
              if (isset($error)) {
                    echo "<div class='alert alert-danger'>
                    <span class='glyphicon glyphicon-exclamation-sign' aria-hidden= 'true'> ".$error."</span>
                    </div>";
                }

             ?>
          </form>
            </div>
        </div>
    </div>
</div>

<div class="panel-footer" style="text-align: center;"> <?php  echo $res_fetch['name']; ?></div>
</body>
    <script>
    document.getElementById("error-div").style.display = "none";
    function validate(){
        var descript = document.getElementById('description').value;
        var message='';
        if (descript=="" ) {
            message="All fields are required";
        }
         if (message!='') {
            document.getElementById("error-div").style.display = "block";
            document.getElementById('error-div').innerHTML=message;
            return false;
        }else{
            return true;
        }
      }
        </script>
</html>