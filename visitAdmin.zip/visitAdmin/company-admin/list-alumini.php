<?php 
   session_start();
     if (!isset($_SESSION['admin-login'])){
      // header(string:"Location:login.php");
      header("location:login.php");
      exit();
     }else{
      $id= $_SESSION['admin-login'];
     } 
     ?>

<?php

       include '../partials/header.php' ?>
 
<body>
   <?php include '../partials/college-nav.php' ?>

   <?php 
   // to retrieve data from table
    $sql = "SELECT * FROM college where user_id=".$id;
      $result= mysqli_query($conn,$sql);
                $res_fetch = mysqli_fetch_assoc($result);
                $college_id=$res_fetch['id'];
  
    $result1= mysqli_query($conn, "SELECT * FROM alumini where college_id=$college_id");
    
    ?>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-4">
           <?php include '../partials/side-menu.php' ?>
        </div>
        <div class="col-md-8">
         <div class="panel panel-default">
          <!-- Default panel contents -->
          <div class="panel-heading">List of alumni</div>
        <?php 
          if (isset($_SESSION['deleted'])) {
            echo "<div class='alert alert-success' id='success-div'>
            <span class='glyphicon glyphicon-exclamation-sign' aria-hidden= 'true' > Successfully deleted </span>
          </div>";
           unset($_SESSION['deleted']);
          }
         ?>

          <!-- Table -->
          <table class="table">
            <tr>
             
              <th>Name</th>
               <th>Address</th>
                <th>Current Status</th>
              <th>Action</th>
            </tr>
            <?php 
              while ($res = mysqli_fetch_assoc($result1)) {?>
                <tr>
                  
                  <td><?= $res['name']?></td>
                  <td><?= $res['address']?></td>
                  <td><?= $res['current_status']?></td>
                
                 <td> <a href="../colege-admin/view-alumini.php?id=<?=$res['user_id']?>" >view</a>| </td>
                </tr>
            <?php
              }        
            ?>
          </table>
        </div>
        </div>
    </div>
</div>

<div class="panel-footer" style="text-align: center;">© <?php echo '$college_id'; ?></div>

</body>
</html>