<?php 
   session_start();
     if (!isset($_SESSION['admin-login'])){
      // header(string:"Location:login.php");
      header("location:login.php");
      exit();
     }else{
      $id= $_SESSION['admin-login'];
     } 
     ?>

<?php

       include '../partials/header.php' ?>
 
<body>
   <?php include '../partials/college-nav.php' ?>

   <?php 
       $sql = "SELECT * FROM college where user_id=".$id;
      $resu= mysqli_query($conn,$sql);
                $res_fetch = mysqli_fetch_assoc($resu);
                $college_id=$res_fetch['id'];
  




?>


<body>
  

   <?php 
   // to retrieve data from table
    $result= mysqli_query($conn, "SELECT * FROM alumini where status='1' and college_id='$college_id'");
    ?>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-4">
           <?php include '../partials/side-menu.php' ?>
        </div>
        <div class="col-md-8">
         <div class="panel panel-default">
          <!-- Default panel contents -->
          <div class="panel-heading">List of alumini</div>
       <?php 
         if (isset($_SESSION['deleted'])) {
            echo "<div class='alert alert-success' id='success-div'>
            <span class='glyphicon glyphicon-exclamation-sign' aria-hidden= 'true' > Successfully deleted </span>
          </div>";
           unset($_SESSION['deleted']);
          }
         ?> 

          <!-- Table -->
          <table class="table">
            <tr>
              <th>name</th>
              <th>address</th>
              <th>current status</th>
              <th>pass out year</th>
              
            </tr>
            <?php 
              while  ($res = mysqli_fetch_assoc($result)) {?>
                <tr>
                  <td><?= $res['name']?></td>
                  <td><?= $res['address']?></td>
                  <td><?= $res['current_status']?></td>
                  <td><?= $res['pass_out_year']?></td>

                  <td><a href="../college-admin/view-alumini.php?id=<?=$res['user_id']?>" title="Edit">view</i></a> 
                </tr>
            <?php
              }        
            ?>
          </table>
        </div>
        </div>
    </div>
</div>
<div class="panel-footer" style="text-align: center;">© Kathford International</div>

</body>
</html>