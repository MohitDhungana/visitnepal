<?php 
 require_once($_SERVER['DOCUMENT_ROOT'] . '/minor/assets/database/dbconfig.php');
 session_start();
 if(isset($_POST['email']) and isset($_POST['pwd']) and isset($_POST['uname']) and isset($_POST['usertype']) ) {
    $email= $_POST['email'];
    $username= $_POST['uname'];
    $password= md5($_POST['pwd']);
    $usertype= $_POST['usertype'];
    if ($email =="" ||$password == ""||$username =="") {
        $message="Field Required";
        echo $message;
    
    }else{
         $sql="SELECT * FROM user WHERE email='$email' AND password='$password'";

           }
         if(mysqli_num_rows(mysqli_query($conn,$sql))){
          //count rows that matches email and password
            if ($usertype == 'mainadmin') { 
                 $_SESSION['main-login']=$sql['id']; //create new user session as user loggedin for admind
                header("location:../main-admin/add-college.php");
            }else{
                $_SESSION['admin-login']=$sql['id']; // session for general user
                //$all_data_user=mysqli_fetch_assoc(mysqli_query($conn,$sql));
                 //$_SESSION['user-login-name']=$all_data_user['name']
                 header("location:product.php");
            }
         }
           
         else{
            $error = 'Invalid login informations';
             echo $error;
           }  
      }
 ?>
 















<!DOCTYPE html>
<html>   
<head>
    <link rel="stylesheet" type="text/css" href="../../assets/bootstrap/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <div class="header">
            Login
        </div>
        <div class="loginForm">
            <form method="post" id="login_form" onsubmit="return validate();" action="login.php">
                <input id="email" type="text" placeholder="Enter Email" name="txtEmail" value="<?= isset($username)?$username:""?>">
                <input id="password" type="password" placeholder="Enter Password" name="txtPassword" value="<?= isset($password)?$password:""?>">
                <label>Select Usertype:</label>
                    <label class="radio radio-inline new">
                    <input type="radio" name="usertype" value="Admin">
                    Admin</label><label class="radio radio-inline" >
                    <input type="radio" name="usertype" value="General" checked="true">
                    General</label>
                    <br>
                    <input type="submit" name="Login" name="btnSubmit" value="Login">
                    <div class="alert alert-danger" id="error-div">
                        <span class="glyphicon glyphicon-exclamation-sign" id="error" aria-hidden= 'true'></span>
                    </div>
                    <div>
                     <p><strong>do not have account?</strong></p>
                   <a href="register.php" class="btn btn-default  name="register"  role="button" >register</a>
                 </div>
                    

                   
                    

                    <center><a href="forgot_password.php">forgot password</a></center>
                    <br>
                   
    
                    <?php 
                    if (isset($error)) {
                        echo "<div class='alert alert-danger'>
                        <span class='glyphicon glyphicon-exclamation-sign' aria-hidden= 'true'> ".$error."</span>
                    </div>";
                }
                ?>
            </form>
        </div>
    </div>
</body>
<style>
    .new{
       margin-top: -3px; 
    }
    .container{
        width: 400px;
        background-color: #ccc;
        margin: auto;
        border: 3px solid;
        margin-top: 100px;
    }
    .header{
        background-color: #999;
        height: 30px;
        margin: 0px;
        text-align: center;
        color: #fff;
        font-size: 20px;
    }
    input[type=text], input[type=password] {
        width: 350px;
        padding:12px 20px;
        margin:10px 0;
        display: inline-block;
        border: 1px solid #ccc;
        box-sizing: border-box;
        margin-left: 0px;
        font-size: 15px;
    }
    input[type=submit]{
        background-color: #4CAF50;
        color: white;
        padding:10px 20px;
        margin: 10px 0;
        border: none;
        cursor: pointer;
        width: 350px;
        margin-left: 0px;
    }
    input[type=button]{
        background-color: #4CAFff;
        color: white;
        padding:10px 20px;
        margin:10px 0;
        border: none;
        cursor: pointer;
        width: 350px;
        margin-left: 0px;
    }
</style>

<script>
    document.getElementById("error-div").style.display = "none";
    function validate(){
        var email = document.getElementById('email').value;
        var password = document.getElementById('password').value;
        var message='';
        if (password=="" || email=="") {
            message="All fields are required";
        }
        if (!validateEmail(email)) {
            message="Please enter a valid email";
        }
        if (message!='') {
            document.getElementById("error-div").style.display = "block";
            document.getElementById('error-div').innerHTML=message;
            return false;
        }else{
            return true;
        }
    }
    function validateEmail(email) {
        var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        return re.test(email);
    }
</script>

<script
src="https://code.jquery.com/jquery-3.2.1.min.js"
integrity="sha256-hwg4gsxgFZhOsEEamdOYGBf13FyQuiTwlAQgxVSNgt4="
crossorigin="anonymous">
</script>
</html>