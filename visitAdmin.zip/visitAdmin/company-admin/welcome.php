 <?php
  require_once($_SERVER['DOCUMENT_ROOT'] . '/minor/assets/database/dbconfig.php');
 session_start();
 if (isset($_GET['id'])) {
      $college_id = $_GET['id'];
      $result= mysqli_query($conn, "SELECT * FROM college WHERE id = '$college_id'");
      $res = mysqli_fetch_assoc($result);

    }
  
    ?>


<?php
#$uname="admin";
#$pwd="admin";
    session_start();
    if (isset($_SESSION[$res['name'])) {

  			echo "<h1>welcome".$_SESSION[$res['name']."</h1>";

  			echo "<a href='product.php'>PRODUCT</a><br>";

  			echo"<br><a href='logout.php'><input type=button value=logout
  			 name=logout></a>"; 
  			}
  			/*else{
  				if($_POST['uname']==$uname && $_POST['pwd']==$pwd){
  					$_SESSION['uname']=$uname;
  					echo "<script>loation.href='welcome.php'</script>";
  				}
  				else{
  					echo "<script>alert('username or password incorrect!!')</script>";

  					echo "<script>location.href='login.php'</script>";
  				}
  			}*/
?>