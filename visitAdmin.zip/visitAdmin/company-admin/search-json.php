<?php   
$conn= mysqli_connect('localhost','root','','minorproject') or die("Error in connection");


if (isset($_GET['location']) || isset($_GET['name']) || (isset($_GET['lhitno']) && 
	isset($_GET['uhitno'])) || (isset($_GET['uscore']) && isset($_GET['lscore'])))  {
       $view_location=$_GET['location'];
       $view_name=$_GET['name'];
       $view_uscore=$_GET['uscore'];
       $view_lhitno=$_GET['lhitno'];
       $view_uhitno=$_GET['uhitno'];
       $view_lscore=$_GET['lscore'];
      


      if($view_location == null){
       	    $view_location="%%%";
       	}
       if($view_name == null){
       	    $view_name="%%%";
       	}
       	if($view_uscore == null and $view_lscore == null){
       	   $view_lscore=0;
       	   $view_uscore=100;
       	}
       	if( $view_uhitno==null and $view_lhitno==null){
       		$view_uhitno=100;
       		$view_lhitno=0;
       	}

       }else{
       	echo 'ERROR';
       }
       	
      
      

  $sql = "SELECT * FROM college WHERE name like'%$view_name%' and location like'%$view_location%' and score>$view_lscore and score< $view_uscore and hitno>$view_lhitno and hitno<$view_lhitno";

  $result = mysqli_query($conn, $sql);  
  $json_array = array();  
  while($row = mysqli_fetch_assoc($result))  
  {  
     $json_array[] = $row;
    
   }  
           /*echo '<pre>';  
           print_r(json_encode($json_array));  
           echo '</pre>';*/  
    echo json_encode($json_array);  
    ?>  
