<?php 
   session_start();
     if (!isset($_SESSION['admin-login'])){
      // header(string:"Location:login.php");
      header("location:login.php");
      exit();
     }else{
      $id= $_SESSION['admin-login'];
     } 
     ?>

<?php

       include '../partials/header.php' ?>
 
<body>
   <?php include '../partials/college-nav.php' ?>

   <?php 
       $sql = "SELECT * FROM college where user_id=".$id;
      $result= mysqli_query($conn,$sql);
                $res_fetch = mysqli_fetch_assoc($result);
                $college_id=$res_fetch['id'];
  
    $result1= mysqli_query($conn, "SELECT * FROM contact where college_id=$college_id");
  
    
  
   

  ?>


  


<div class="container-fluid">
    <div class="row">
        <div class="col-md-4">
            <?php include '../partials/side-menu.php' ?>
        </div>
        <div class="col-md-8">
            <div class="well">
            <h2>view contact </h2>
             
             <?php 
             $res = mysqli_fetch_assoc($result1);?>
              <h3>telephone no </h3>
             <form> 
             <input type="text" class="form-control" rows="7" id="telephone" value="<?= $res['tel_no']?>" name="review">
            <br>   
          </form>
           <h3>postal address </h3>
             <form> 
             <input type="text" class="form-control" rows="7" id="postal address" value="<?= $res['postal_add']?>" name="review">
            <br>   
          </form>
           <h3>email </h3>
             <form> 
             <input type="text" class="form-control" rows="7" id="email" value="<?= $res['email']?>" name="review">
            <br>   
          </form>
          <h3>fax no </h3>
             <form> 
             <input type="text" class="form-control" rows="7" id="email" value="<?= $res['fax_no']?>" name="review">
            <br>   
          </form>
          <form>
          <a href="../college-admin/edit-contact.php?id=<?=$college_id?>" title="Edit"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
          <br>
          <form>

            </div>
        </div>
    </div>
</div>
<div class="panel-footer" style="text-align: center;">© Kathford International</div>
</body>

</html> 