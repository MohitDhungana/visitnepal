<?php include '../partials/header.php' ?>
<body>
   <?php include '../partials/college-nav.php' ?>

   <?php 
   // to retrieve data from table
    $result= mysqli_query($conn, "SELECT * FROM college where id='2'");
    while ($res = mysqli_fetch_assoc($result)) {
                echo $res['name'];
            }
    
    ?>