<?php include '../partials/header.php' ?>
<?php
  //to get the id of the problem
//require_once($_SERVER['DOCUMENT_ROOT'] . '/final/assets/database/dbconfig.php');
 if (isset($_GET['id'])) {
    $college_id = $_GET['id'];
      //to save problem
    if (isset($_POST['submit'])) {
       $name = $_POST['txt_title'];
      $post = $_POST['txt_description'];
      $qualification = $_POST['txt_description'];
      $email = $_POST['txt_description'];
       $sql_check_remedies="SELECT * FROM `staff` WHERE post='$post' and name='$name'";
    $result_check=mysqli_query($conn,$sql_check_remedies); //run the query $sql
       
    if(mysqli_num_rows($result_check)){
         //count rows that matches email and password
            $error = 'This staff is already exits';
          }
     else{   
        $temp = explode(".",$_FILES["fileToUpload"]["name"]);
      $filename = "image_".round(microtime(true)).'.'. end($temp);
      $target_dir = "../image-upload/";
    $target_file = $target_dir . basename($filename);
    $uploadOk = 1;
    $imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
    // Check if image file is a actual image or fake image
        $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
        if($check !== false) {
            $uploadOk = 1;
        } else {
            echo "File is not an image.";
            $uploadOk = 0;
        } 
if ($uploadOk == 1) {
      move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file);  
       $que = "INSERT INTO `staff`(college_id, name,post,qualification,email,image) VALUES ('$college_id','$name','$post','$qualification','$email','$filename') ";
     }
        if(mysqli_query($conn,$que)){
           $success = 'true';
          }else{
        $error = 'true';
      }
    }
    }
  }else{
    header("location:add-staff.php");
  }
?>

   <body>
   <?php include '../partials/nav.php' ?>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-4">
            <?php include '../partials/side-menu.php' ?>
        </div>
        <div class="col-md-8">
            <div class="well">
            <h2>Add staff</h2>
              <form method="POST" name="myForm"  onsubmit="return validate();" action="add-remedies.php?id=<?=$problem_id?>" enctype="multipart/form-data">
              <div class="form-group">
            <label for="comment">name</label>
            <textarea class="form-control" rows="1" id="title" name="txt_title"></textarea>
          </div>
             <div class="form-group">
            <label for="comment">post</label>
            <textarea class="form-control" rows="2" id="description" name="txt_description"></textarea>
          </div>
           <div class="form-group">
            <label for="comment">qualification</label>
            <textarea class="form-control" rows="2" id="qualification" name="txt_description"></textarea>
          </div>
           <div class="form-group">
            <label for="comment">email</label>
            <textarea class="form-control" rows="1" id="email" name="txt_description"></textarea>
          </div>
         <div class="form-group">
          <input type="file" name="fileToUpload" id="fileToUpload">
        </div>
            <div class="alert alert-danger" id="error-div" style="display: none;">
              <span class="glyphicon glyphicon-exclamation-sign" id="error" aria-hidden= 'true' >your account is not register</span>
            </div>
            <div class="form-group">
              <button class="btn btn-sucess pull-right" style="margin-right: 10px" type="submit" name="submit">save</button>
            <br></div>
            <?php 
              if (isset($success)) {
                echo "<div class='alert alert-success' id='success-div'>
                    <span class='glyphicon glyphicon-exclamation-sign' aria-hidden= 'true' > Added Successfully </span>
                    </div>";
              }
              if (isset($error)) {
                    echo "<div class='alert alert-danger'>
                    <span class='glyphicon glyphicon-exclamation-sign' aria-hidden= 'true'> ".$error."</span>
                    </div>";
                }

             ?>
          </form>
            </div>
        </div>
    </div>
</div>

<div class="panel-footer" style="text-align: center;">© Kathford International</div>
</body>
    <script>
    document.getElementById("error-div").style.display = "none";
    function validate(){
        var descript = document.getElementById('description').value;
        var message='';
        if (descript=="" ) {
            message="All fields are required";
        }
         if (message!='') {
            document.getElementById("error-div").style.display = "block";
            document.getElementById('error-div').innerHTML=message;
            return false;
        }else{
            return true;
        }
      }
        </script>
</html>