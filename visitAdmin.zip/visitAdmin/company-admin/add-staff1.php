
<html>
<?php 
   session_start();
     if (!isset($_SESSION['admin-login'])){
      // header(string:"Location:login.php");
      header("location:login.php");
      exit();
     }else{
      $id= $_SESSION['admin-login'];
     } 
     ?>

<?php

       include '../partials/header.php' ?>
  <?php
         $sql = "SELECT * FROM college where user_id=".$id;
      $result= mysqli_query($conn,$sql);
                $res_fetch = mysqli_fetch_assoc($result);
                $college_id=$res_fetch['id'];
    ?>

<?php
 if (isset($_POST['submit'])) {
      $post=$_POST['txt_post'];
      $name = $_POST['txt_name'];
      $qualification = $_POST['txt_qualification'];
      $email = $_POST['txt_email'];
       $sql_check_staff="SELECT * FROM `staff` WHERE post='$post' and name='$name' and email=$email";
        $result_check=mysqli_query($conn,$sql_check_staff); //run the query $sql
       
    if(mysqli_num_rows($result_check)){
         //count rows that matches email and password
            $error = 'This staff already exits';
          }
    else{   
        $temp = explode(".",$_FILES["fileToUpload"]["name"]);
        $filename = "image_".round(microtime(true)).'.'. end($temp);
        $target_dir = "../image-upload/";
        $target_file = $target_dir . basename($filename);
        $uploadOk = 1;
        $imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
    // Check if image file is a actual image or fake image
        $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
        if($check !== false) {
            $uploadOk = 1;
        } 
        else {
            echo "File is not an image.";
            $uploadOk = 0;
        } 
        if ($uploadOk == 1) {
            move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file);  
             $que = "INSERT INTO `staff`(college_id, name,post,qualification,email,image) VALUES ('$college_id','$name','$post','$qualification','$email','$filename') ";
            }
        else{
            $que = "INSERT INTO `staff`(college_id, name,post,qualification,email) VALUES ('$college_id','$name','$post','$qualification','$email') ";
             }
           }
           if(mysqli_query($conn,$que)){
               $success = 'true';
               echo "sucess";
          }else{
            $error = 'true';
      }
?>
   <body>
   <?php include '../partials/nav.php' ?>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-4">
            <?php include '../partials/side-menu.php' ?>
        </div>
        <div class="col-md-8">
            <div class="well">
            <h2>Add Staff</h2>
              <form method="POST" name="myForm"  onsubmit="return validate();" action="add-staff.php?id=<?=$college_id?>" enctype="multipart/form-data">
              <div class="form-group">
            <label for="comment">Name</label>
            <textarea class="form-control" rows="1" id="name" name="txt_name"></textarea>
          </div>
           <div class="form-group">
            <label for="comment">Email</label>
            <textarea class="form-control" rows="1" id="email" name="txt_email"></textarea>
          </div>

             <div class="form-group">
            <label for="comment">Post</label>
            <textarea class="form-control" rows="1" id="post" name="txt_post"></textarea>
          </div>
           <div class="form-group">
            <label for="comment">Qualification</label>
            <textarea class="form-control" rows="5" id="qualification" name="txt_qualification"></textarea>
          </div>
         <div class="form-group">
          <input type="file" name="fileToUpload" id="fileToUpload">
        </div>
            <div class="alert alert-danger" id="error-div" style="display: none;">
              <span class="glyphicon glyphicon-exclamation-sign" id="error" aria-hidden= 'true' >your account is not register</span>
            </div>
            <div class="form-group">
              <button class="btn btn-sucess pull-right" style="margin-right: 10px" type="submit" name="submit">save</button>
            <br></div>
            <?php 
              if (isset($success)) {
                echo "<div class='alert alert-success' id='success-div'>
                    <span class='glyphicon glyphicon-exclamation-sign' aria-hidden= 'true' > Added Successfully </span>
                    </div>";
              }
              if (isset($error)) {
                    echo "<div class='alert alert-danger'>
                    <span class='glyphicon glyphicon-exclamation-sign' aria-hidden= 'true'> ".$error."</span>
                    </div>";
                }

             ?>
          </form>
            </div>
        </div>
    </div>
</div>

<div class="panel-footer" style="text-align: center;"> <?php  echo $res_fetch['name']; ?></div>
</body>
    <script>
    document.getElementById("error-div").style.display = "none";
    function validate(){
        var descript = document.getElementById('description').value;
        var message='';
        if (descript=="" ) {
            message="All fields are required";
        }
         if (message!='') {
            document.getElementById("error-div").style.display = "block";
            document.getElementById('error-div').innerHTML=message;
            return false;
        }else{
            return true;
        }
      }
        </script>
</html>