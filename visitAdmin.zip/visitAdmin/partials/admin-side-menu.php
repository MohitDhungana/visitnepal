 <ul class="list-group">
               <li class="list-group-item"><a href="list-places.php">List Places</a></li>
               <li class="list-group-item"><a href="list-hotel.php">List Hotel</a></li>
               <li class="list-group-item"><a href="list-sports.php">List Sports</a></li>
               <li class="list-group-item"><a href="list-package.php">List Packages</a></li>
               <li class="list-group-item"><a href="list-companies.php">List Companies</a></li>
                <li class="list-group-item"><a href="add-place.php">Add Place</a></li>
                <li class="list-group-item"><a href="add-sports.php">Add Sports</a></li>
                <li class="list-group-item"><a href="add-Companies.php">Add Companies</a></li>
                <li class="list-group-item"><a href="add-hotel.php">Add Hotel</a></li>
                <li class="list-group-item"><a href="user.php">users</a></li>
                <li class="list-group-item"><a href="approved-user.php">Approved user</a></li>
                 <li class="list-group-item"><a href="unapproved-user.php">Unapproved user</a></li>
                
                
                
            </ul>
