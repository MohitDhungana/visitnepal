<?php include '../partials/header.php' ?>
<body>
   <?php include '../partials/nav.php' ?>


<div class="container-fluid">
    <div class="row">
        <div class="col-md-4">
           <?php include '../partials/admin-side-menu.php' ?>
        </div>
    </div>
</div>
    
<div class="panel-footer" style="text-align: center;">© Visit Nepal</div>

</body>
</html>