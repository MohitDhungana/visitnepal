<footer class="footer">
			
			<div class="container">

				<div class="row footer_contact_row">
					<div class="col-xl-10 offset-xl-1">
						<div class="row">

							<!-- Footer Contact Item -->
							<div id="aboutus" class="col-xl-4 footer_contact_col">
								<div class="footer_contact_item d-flex flex-column align-items-center justify-content-start text-center">
									<div class="footer_contact_icon"><img src="images/sign.svg" alt=""></div>
									<div class="footer_contact_title">give us a call</div>
									<div class="footer_contact_list">
										<ul>
											<li>Office Landline: +977 9846354654</li>
											<li>Mobile: +44 5567 89 3322 332</li>
										</ul>
									</div>
								</div>
							</div>

							<!-- Footer Contact Item -->
							

							<!-- Footer Contact Item -->
							

						</div>
					</div>
				</div>
			</div>
			<div class="col text-center">
				<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
				Copyright &copy;<script>
					document.write(new Date().getFullYear());
				</script> All rights reserved   
				<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
			</div>
		</footer>

	<script src="js/jquery-3.2.1.min.js"></script>
	<script src="styles/bootstrap4/popper.js"></script>
	<script src="styles/bootstrap4/bootstrap.min.js"></script>
	<script src="plugins/OwlCarousel2-2.2.1/owl.carousel.js"></script>
	<script src="plugins/Isotope/isotope.pkgd.min.js"></script>
	<script src="plugins/scrollTo/jquery.scrollTo.min.js"></script>
	<script src="plugins/easing/easing.js"></script>
	<script src="plugins/parallax-js-master/parallax.min.js"></script>
	<script src="js/custom.js"></script>
</body>

</html>