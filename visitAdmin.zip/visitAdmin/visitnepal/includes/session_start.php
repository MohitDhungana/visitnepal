<?php 
session_start();
     if (!isset($_SESSION['user-login'])){
      // header(string:"Location:login.php");
      header("location:../index.php");
      exit();
     }else{
      $id= $_SESSION['user-login'];
     }?>
