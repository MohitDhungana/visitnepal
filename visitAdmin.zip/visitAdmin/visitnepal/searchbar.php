<div class="home_search">
			<div class="container">
				<div class="row">
					<div class="col">
						<div class="home_search_container">
							<div class="home_search_title">Search for your trip</div>
							<div class="home_search_content">


								<form action="search.php" class="home_search_form" id="home_search_form" method="post">
									<div class="d-flex flex-lg-row  justify-content-lg-between justify-content-start">
										<input type="text" class="col-lg" placeholder="Search" required="required" name="search">
										<span class="input-group-btn">
											<button class="home_search_button">search</button></span>
									</div>
                                </form>
                                
                                
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>