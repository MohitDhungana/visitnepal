
<?php 
include "includes/session_start.php" ?>





<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="robots" content="noindex, nofollow">

    <title>User Profile  - Bootsnipp.com</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <style type="text/css">
                  input.hidden {
    position: absolute;
    left: -9999px;
}
.center_garne{
  text-align="center";
}

#profile-image1 {
    cursor: pointer;
  
     width: 100px;
    height: 100px;
  border:2px solid #03b1ce ;}
  .tital{ font-size:16px; font-weight:500;}
   .bot-border{ border-bottom:1px #f8f8f8 solid;  margin:5px 0  5px 0}  
    </style>
    <script src="//code.jquery.com/jquery-1.10.2.min.js"></script>
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
    <script type="text/javascript">
        window.alert = function(){};
        var defaultCSS = document.getElementById('bootstrap-css');
        function changeCSS(css){
            if(css) $('head > link').filter(':first').replaceWith('<link rel="stylesheet" href="'+ css +'" type="text/css" />'); 
            else $('head > link').filter(':first').replaceWith(defaultCSS); 
        }
        $( document ).ready(function() {
          var iframe_height = parseInt($('html').height()); 
          window.parent.postMessage( iframe_height, 'https://bootsnipp.com');
        });
    </script>
     <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>





 <!--  <?php include 'includes/db.php' ?>
<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script> -->
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

</head>
<body >

<nav class="navbar navbar-inverse">
        <div class="container-fluid">
            <div class="navbar-header">
                <a class="navbar-brand" href="index.php">Visit Nepal</a>
            </div>
            <ul class="nav navbar-nav">
                <li class="active"><a href="index.php">Home</a></li>
                    <li><a href="list_places.php">Places</a></li>
                    <li><a href="list_all_package.php">Packages</a></li>
                    <li><a href="list_sports.php">Sports</a></li>
                    <li><a href="create_package.php">Create Package</a></li>
                    <li><a href="list_all_created_packages.php">Created Packages</a></li>
                <!-- <li><a href="#">Contact us</a></li> -->
            </ul>
        </div>
    </nav>
<br>
<br>
<br>
<br>

 
<!-- <?php include 'includes/db.php' ?>
<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script> -->
<!------ Include the above in your HEAD tag ---------->

<?php
if (isset($_POST['submit'])) {
  $name= $_POST['name'];
  $duration = $_POST['duration'];
   $price= $_POST['price'];
   $destination= $_POST['destination'];
  $inclusion= $_POST['inclusion'];


    $sql_check_places ="SELECT * FROM `createdpackages` WHERE name='$name' AND user_id='$id' ";
    $result_check=mysqli_query($connection,$sql_check_places); //run the query $sql
       
    if(mysqli_num_rows($result_check)){
            $error = 'This package is already exits';
          }else{
      $que = "INSERT INTO `createdpackages` (`name`,`duration`,`price`,`destination`,`inclusion`,`user_id`
    ) VALUES ('$name','$duration','$price','$destination','$inclusion','$id')";
    }



  
  if(mysqli_query($connection,$que)){
    $success = 'true';
     header("location:list_all_created_packages.php");
  }else{
    $error = 'true';
  }
   $q=mysqli_query($connection,$que);
        if(!$q){
         die(mysqli_error($connection));
}
}



   ?>
<div class="container">
  <div class="row">
   
    <div class="col-md-9">
        <div class="card">
            <div class="card-body">
                <div class="row">
                    <div class="col-md-12">
                        <h4>create package</h4>
                        <hr>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <form method="POST" action="create_package.php">
                              <div class="form-group row">
                                <label for="username" class="col-4 col-form-label">Package Name</label> 
                                <div class="col-8">
                                  <input id="name" name="name" placeholder="" class="form-control here" required="required" type="text">
                                </div>
                              </div>
                              <div class="form-group row">
                                <label for="name" class="col-4 col-form-label">Duration</label> 
                                <div class="col-8">
                                  <input id="duration" name="duration" placeholder="" class="form-control here" type="text">
                                </div>
                              </div>
                              <div class="form-group row">
                                <label for="text" class="col-4 col-form-label">price</label> 
                                <div class="col-8">
                                  <input id="price" name="price" placeholder="" class="form-control here" required="required" type="text">
                                </div>
                              </div>
                              <div class="form-group row">
                                <label for="text" class="col-4 col-form-label">Destinations</label> 
                                <div class="col-8">
                                  <input id="destination" name="destination" placeholder="" class="form-control here" required="required" type="text">
                                </div>
                              </div>
                              
                              <div class="form-group row">
                                <label for="email" class="col-4 col-form-label">Inclusions</label> 
                                <div class="col-8">
                                  <input id="inclusion" name="inclusion" placeholder="" class="form-control here" required="required" type="text">
                                </div>
                              </div>

                              
                              <div class="form-group column">
                                <div class="offset-4 col-8">
                                  <button name="submit" type="submit" class="btn btn-primary">Post</button>
                                  <button class="btn btn-danger"><a href="index.php">Home</a></button>
                                </div>

                                
                              </div>
                                
                            </form>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
  </div>
</div>













</body>
</html>



