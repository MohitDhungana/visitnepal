<?php 
	$conn= mysqli_connect('localhost','root','','visitnepal') or die("Error in connection");

 ?>